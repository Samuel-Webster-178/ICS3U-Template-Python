#!/usr/bin/env python3

# Created by Samuel Webster
# Created on March 2022
# This module contains constants


TAU = 6.28
