# ICS3U-Unit2-Unit2-03-Python

[![GitHub's Super Linter](https://github.com/Samuel-Webster-178/ICS3U-Unit2-Unit2-03-Python/workflows/GitHub's%20Super%20Linter/badge.svg)](https://github.com/Samuel-Webster-178/ICS3U-Unit2-Unit2-03-Python/actions)
